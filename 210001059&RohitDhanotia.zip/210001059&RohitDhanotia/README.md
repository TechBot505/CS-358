## Going to correct directory

For Question number 1
```
$ que1
$ lex que1.l
$ yacc -d que1.y
$ g++ lex.yy.c y.tab.c -o que1 -ll
$ ./que1
```
For Question number 2
```
$ que2
$ lex que2.l
$ yacc -d que2.y
$ g++ lex.yy.c y.tab.c -o que2 -ll
$ ./que2
```

For Question number 3
```
$ que3
$ lex que3.l
$ yacc -d que3.y
$ g++ lex.yy.c y.tab.c -o que3 -ll
$ ./que3
```

For Question number 4
```
$ que4
$ lex que4.l
$ yacc -d que4.y
$ g++ lex.yy.c y.tab.c -o que4 -ll
$ ./que4
```
